# System Architecture

```mermaid
graph TD
    CLI[CLI Interface] --> |Parses Args| Controller[Pipeline Controller]
    Controller --> |Input Path| IO[IO Utils]
    IO --> |Raw Image| QualityPre[Quality Analyzer - Pre]
    IO --> |Raw Image| Detector[Boundary Detector]
    Detector --> |Corners & Geometric Detection Score| Geom[Geometry module]
    Geom --> |Warped Image| Enhancer[Image Enhancer]
    Enhancer --> |Final Image| IO
    Enhancer --> |Final Image| QualityPost[Quality Analyzer - Post]
    QualityPre --> |Pre-Metrics| Controller
    QualityPost --> |Post-Metrics| Controller
    Controller --> |Report/Logs| CLI
```

# Workflow / Process Flow

```mermaid
flowchart TD
    A[Start] --> B[Load Image]
    B --> B1[Pre-process Quality Analysis]
    B1 --> C{Detect Edges}
    C --> D[Find Contours]
    D --> E{4 Corners Found?}
    E -->|Yes| G[Perspective Transform]
    E -->|No| F{Bounding Box Found?}
    F -->|Yes| G
    F -->|No| Z[Throw DocumentNotFoundError]
    G --> H[Apply Denoising & Enhancement]
    H --> I[Post-process Quality Analysis]
    I --> J[Save Image & Output Metrics]
    J --> K[End]
    Z --> K
```

# Use Case Diagram

```mermaid
flowchart LR
    User([User])
    
    UC1([Run Offline Demo])
    UC2([Scan Single Image])
    UC3([Analyze Image Quality])
    UC4([Process Batch of Images])
    
    User --> UC1
    User --> UC2
    User --> UC3
    User --> UC4
    
    UC4 -.->|includes| UC2
    UC2 -.->|includes| UC3
```

# Sequence Diagram

```mermaid
sequenceDiagram
    actor User
    participant CLI
    participant Pipeline
    participant Detector
    participant Geometry
    participant Enhancer
    participant Quality

    User->>CLI: smartscan scan --input img.jpg
    CLI->>Pipeline: process_image(img.jpg)
    Pipeline->>Quality: analyze_quality(image)
    Quality-->>Pipeline: pre_metrics
    Pipeline->>Detector: detect_document(image)
    Detector-->>Pipeline: corners, geometric_score
    Pipeline->>Geometry: four_point_transform(image, corners)
    Geometry-->>Pipeline: warped_image
    Pipeline->>Enhancer: enhance_image(warped_image)
    Enhancer-->>Pipeline: final_image
    Pipeline->>Quality: analyze_quality(final_image)
    Quality-->>Pipeline: post_metrics
    Pipeline-->>CLI: result & combined_metrics
    CLI-->>User: Console Output
```

# Component / Class Diagram

```mermaid
classDiagram
    class CLI {
        +main()
    }
    class Pipeline {
        +process_image()
    }
    class Batch {
        +process_batch()
    }
    class Detector {
        +detect_document(image) tuple
    }
    class Geometry {
        +order_points(pts) array
        +four_point_transform(image, pts) image
    }
    class Enhancer {
        +enhance_image(image, mode) image
    }
    class Quality {
        +analyze_quality(image) dict
    }
    class IOUtils {
        +load_image(path) image
        +save_image(image, path)
    }

    CLI --> Pipeline
    CLI --> Batch
    Batch --> Pipeline
    Pipeline --> Detector
    Pipeline --> Geometry
    Pipeline --> Enhancer
    Pipeline --> Quality
    Pipeline --> IOUtils
```
