import pytest
from smartscan.io_utils import load_image, save_image
import os
import numpy as np

def test_load_missing_image():
    with pytest.raises(FileNotFoundError):
        load_image("does_not_exist.jpg")

def test_save_and_load_image(tmp_path):
    path = tmp_path / "test.png"
    img = np.zeros((100, 100, 3), dtype=np.uint8)
    save_image(img, str(path))
    
    loaded = load_image(str(path))
    assert loaded.shape == (100, 100, 3)
