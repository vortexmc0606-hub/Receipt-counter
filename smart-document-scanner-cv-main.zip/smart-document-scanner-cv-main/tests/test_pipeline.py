import numpy as np
import cv2
import os
import pytest
from smartscan.pipeline import process_image
from smartscan.detector import DocumentNotFoundError

def test_pipeline_success(tmp_path):
    input_path = tmp_path / "input.jpg"
    output_path = tmp_path / "output.png"
    
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    pts = np.array([[100, 100], [400, 100], [400, 400], [100, 400]], np.int32)
    cv2.fillPoly(img, [pts], (200, 200, 200))
    cv2.imwrite(str(input_path), img)
    
    report = process_image(str(input_path), str(output_path), mode="otsu")
    
    assert os.path.exists(str(output_path))
    assert "geometric_score" in report
    assert "input_sharpness" in report
    assert "output_sharpness" in report
    assert report["geometric_score"] > 0.5

def test_pipeline_failure(tmp_path):
    input_path = tmp_path / "input.jpg"
    output_path = tmp_path / "output.png"
    
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    cv2.imwrite(str(input_path), img)
    
    with pytest.raises(DocumentNotFoundError):
        process_image(str(input_path), str(output_path), mode="otsu")
