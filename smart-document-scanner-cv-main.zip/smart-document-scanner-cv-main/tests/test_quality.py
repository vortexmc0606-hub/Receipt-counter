import numpy as np
import cv2
from smartscan.quality import analyze_quality

def test_analyze_quality_blurry():
    # Create a simple image and blur it heavily
    img = np.zeros((100, 100, 3), dtype=np.uint8)
    cv2.line(img, (10, 10), (90, 90), (255, 255, 255), 2)
    blurred = cv2.GaussianBlur(img, (21, 21), 0)
    
    quality = analyze_quality(blurred)
    # Variance should be very low
    assert quality["sharpness"] < 100
    assert "Blurry" in quality["recommendation"]

def test_analyze_quality_overexposed():
    img = np.ones((100, 100, 3), dtype=np.uint8) * 250
    # Draw some black lines to make it sharp
    for i in range(10, 100, 10):
        cv2.line(img, (0, i), (100, i), (0, 0, 0), 1)
    quality = analyze_quality(img)
    # Brightness should still be high because most of the image is white
    assert quality["brightness"] > 220
    assert "Overexposed" in quality["recommendation"]
