import numpy as np
import cv2
import pytest
from smartscan.detector import detect_document, DocumentNotFoundError

def test_detect_document_rejects_circle():
    # A circle has an extent of ~0.78, which is < 0.85, so it should fail
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    cv2.circle(img, (250, 250), 150, (255, 255, 255), -1)
    
    with pytest.raises(DocumentNotFoundError):
        detect_document(img)
    
def test_detect_document_extreme_fallback_raises_error():
    # Completely black image, no contours
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    
    with pytest.raises(DocumentNotFoundError):
        detect_document(img)
        
def test_detect_document_success():
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    # Draw a big rectangle that looks like a document
    pts = np.array([[100, 100], [400, 100], [400, 400], [100, 400]], np.int32)
    cv2.fillPoly(img, [pts], (255, 255, 255))
    
    corners, geometric_score = detect_document(img)
    assert corners.shape == (4, 2)
    assert geometric_score > 0.70  # High geometric_score for actual 4-point polygon

def test_detect_document_skewed_success():
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    # Skewed quad
    pts = np.array([[150, 100], [450, 120], [400, 400], [120, 380]], np.int32)
    cv2.fillPoly(img, [pts], (255, 255, 255))
    
    corners, geometric_score = detect_document(img)
    assert corners.shape == (4, 2)
    assert geometric_score > 0.70
