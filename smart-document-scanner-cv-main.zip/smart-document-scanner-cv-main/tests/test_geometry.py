import numpy as np
from smartscan.geometry import order_points

def test_order_points():
    # Points not in order
    pts = np.array([
        [100, 100],  # br
        [0, 100],    # bl
        [100, 0],    # tr
        [0, 0]       # tl
    ], dtype="float32")
    
    ordered = order_points(pts)
    
    # Expected: tl(0,0), tr(100,0), br(100,100), bl(0,100)
    assert np.array_equal(ordered[0], [0, 0])
    assert np.array_equal(ordered[1], [100, 0])
    assert np.array_equal(ordered[2], [100, 100])
    assert np.array_equal(ordered[3], [0, 100])
