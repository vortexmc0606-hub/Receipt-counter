import numpy as np
import cv2
import os
import csv
from smartscan.batch import process_batch

def test_batch_processing(tmp_path):
    input_dir = tmp_path / "input"
    output_dir = tmp_path / "output"
    input_dir.mkdir()
    
    # Create 1 valid image, 1 invalid image
    valid_path = input_dir / "valid.jpg"
    invalid_path = input_dir / "invalid.jpg"
    
    img = np.zeros((500, 500, 3), dtype=np.uint8)
    pts = np.array([[100, 100], [400, 100], [400, 400], [100, 400]], np.int32)
    cv2.fillPoly(img, [pts], (200, 200, 200))
    cv2.imwrite(str(valid_path), img)
    
    cv2.imwrite(str(invalid_path), np.zeros((500, 500, 3), dtype=np.uint8))
    
    process_batch(str(input_dir), str(output_dir), mode="otsu")
    
    csv_path = output_dir / "scan_report.csv"
    assert os.path.exists(str(csv_path))
    
    with open(csv_path, "r") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        
    assert len(rows) == 2
    # One should be success, one NO_DOCUMENT_FOUND
    statuses = [r["status"] for r in rows]
    assert "SUCCESS" in statuses
    assert "NO_DOCUMENT_FOUND" in statuses
    
def test_batch_empty_dir(tmp_path):
    input_dir = tmp_path / "input"
    output_dir = tmp_path / "output"
    input_dir.mkdir()
    
    # Should not crash, just warn and exit
    process_batch(str(input_dir), str(output_dir))
    assert not os.path.exists(str(output_dir / "scan_report.csv"))
