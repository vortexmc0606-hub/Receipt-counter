import cv2
import os

def load_image(path):
    """
    Load an image from a given path.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Image not found at path: {path}")
    image = cv2.imread(path)
    if image is None:
        raise ValueError(f"Failed to read image at path: {path}")
    return image

def save_image(image, path):
    """
    Save an image to a given path, creating directories if needed.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    cv2.imwrite(path, image)
