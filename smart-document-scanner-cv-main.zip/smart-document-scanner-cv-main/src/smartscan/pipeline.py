import cv2
import os
from smartscan.io_utils import load_image, save_image
from smartscan.detector import detect_document, DocumentNotFoundError
from smartscan.geometry import four_point_transform
from smartscan.enhancer import enhance_image
from smartscan.quality import analyze_quality

def process_image(input_path, output_path, mode="adaptive", boundary_output_path=None):
    """
    Main pipeline to process a single image.
    """
    image = load_image(input_path)
    
    # Pre-processing quality analysis
    pre_quality = analyze_quality(image)
    
    # 1. Detect boundaries
    try:
        corners, geometric_score = detect_document(image)
    except DocumentNotFoundError as e:
        # Re-raise the error so the batch processor or caller can handle it
        raise e
    
    # Optional: save boundary output
    if boundary_output_path:
        annotated = image.copy()
        cv2.drawContours(annotated, [corners.astype(int)], -1, (0, 255, 0), 2)
        save_image(annotated, boundary_output_path)
        
    # 2. Warp perspective
    warped = four_point_transform(image, corners)
    
    # 3. Enhance
    enhanced = enhance_image(warped, mode=mode)
    
    # 4. Save result
    save_image(enhanced, output_path)
    
    # Post-processing quality analysis
    post_quality = analyze_quality(enhanced)
    
    # Combine results
    final_report = {
        "geometric_score": geometric_score,
        "input_sharpness": pre_quality["sharpness"],
        "input_brightness": pre_quality["brightness"],
        "input_contrast": pre_quality["contrast"],
        "input_recommendation": pre_quality["recommendation"],
        "output_sharpness": post_quality["sharpness"],
        "output_brightness": post_quality["brightness"],
        "output_contrast": post_quality["contrast"],
        "output_recommendation": post_quality["recommendation"]
    }
    
    return final_report
