import cv2
import numpy as np

class DocumentNotFoundError(Exception):
    """Exception raised when a document cannot be detected in the image."""
    pass

def detect_document(image):
    ratio = image.shape[0] / 500.0
    orig = image.copy()
    resized = cv2.resize(image, (int(image.shape[1] / ratio), 500))
    image_area = resized.shape[0] * resized.shape[1]

    gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(gray, 75, 200)

    # Close the edges to repair broken contours (common in noisy images)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    edged = cv2.morphologyEx(edged, cv2.MORPH_CLOSE, kernel)

    cnts, _ = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)[:5]
    
    screenCnt = None
    geometric_score = 0.0

    for c in cnts:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.04 * peri, True)

        if len(approx) == 4:
            area = cv2.contourArea(c)
            if area > 0.10 * image_area:
                screenCnt = approx
                geometric_score = min(0.99, 0.70 + (area / image_area) * 0.29)
                break

    if screenCnt is None:
        for c in cnts:
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.02 * peri, True)
            if len(approx) <= 6:
                area = cv2.contourArea(c)
                hull = cv2.convexHull(c)
                hull_area = cv2.contourArea(hull)
                if hull_area > 0:
                    solidity = area / hull_area
                    if area > 0.10 * image_area and solidity > 0.90:
                        rect = cv2.minAreaRect(c)
                        box = cv2.boxPoints(rect)
                        screenCnt = box.astype(np.int32)
                        geometric_score = min(0.69, 0.40 + (area / image_area) * 0.29)
                        break

    if screenCnt is None:
        raise DocumentNotFoundError("No valid document boundary could be detected in the image.")

    screenCnt = screenCnt.reshape(4, 2) * ratio
    return screenCnt, geometric_score
