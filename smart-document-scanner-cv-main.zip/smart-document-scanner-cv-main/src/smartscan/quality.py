import cv2
import numpy as np

def analyze_quality(image):
    """
    Analyzes an image and returns sharpness, brightness, contrast, and a recommendation.
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Sharpness using Laplacian variance
    sharpness = cv2.Laplacian(gray, cv2.CV_64F).var()

    # Brightness (mean) and contrast (stddev)
    mean, stddev = cv2.meanStdDev(gray)
    brightness = mean[0][0]
    contrast = stddev[0][0]

    recommendation = "Good quality"
    
    # Thresholds are heuristic
    if sharpness < 100:
        recommendation = "Blurry image"
    elif brightness < 60:
        recommendation = "Underexposed image"
    elif brightness > 220:
        recommendation = "Overexposed image"
    elif contrast < 30:
        recommendation = "Low contrast image"

    return {
        "sharpness": float(sharpness),
        "brightness": float(brightness),
        "contrast": float(contrast),
        "recommendation": recommendation
    }
