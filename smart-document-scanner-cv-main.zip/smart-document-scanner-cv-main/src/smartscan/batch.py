import os
import csv
from pathlib import Path
import logging
from smartscan.pipeline import process_image
from smartscan.detector import DocumentNotFoundError

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

def process_batch(input_dir, output_dir, mode="adaptive"):
    """
    Process all supported images inside an input folder.
    """
    input_path = Path(input_dir)
    
    if not input_path.exists() or not input_path.is_dir():
        logging.error(f"Input directory does not exist or is not a directory: {input_dir}")
        return
        
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    supported_extensions = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".webp"}
    results = []
    processed_count = 0
    
    for file_path in input_path.iterdir():
        if file_path.suffix.lower() in supported_extensions:
            processed_count += 1
            out_file = output_path / file_path.name
            logging.info(f"Processing {file_path.name}...")
            
            try:
                quality = process_image(str(file_path), str(out_file), mode=mode)
                results.append({
                    "source_image": file_path.name,
                    "output_path": str(out_file),
                    "status": "SUCCESS",
                    "geometric_score": quality.get("geometric_score", 0.0),
                    "input_sharpness": quality["input_sharpness"],
                    "input_brightness": quality["input_brightness"],
                    "input_contrast": quality["input_contrast"],
                    "input_recommendation": quality["input_recommendation"],
                    "output_sharpness": quality["output_sharpness"],
                    "output_brightness": quality["output_brightness"],
                    "output_contrast": quality["output_contrast"],
                    "output_recommendation": quality["output_recommendation"]
                })
            except DocumentNotFoundError as e:
                logging.warning(f"Skipped {file_path.name}: {e}")
                results.append({
                    "source_image": file_path.name,
                    "output_path": "",
                    "status": "NO_DOCUMENT_FOUND",
                    "geometric_score": 0.0,
                    "input_sharpness": 0.0, "input_brightness": 0.0, "input_contrast": 0.0, "input_recommendation": "N/A",
                    "output_sharpness": 0.0, "output_brightness": 0.0, "output_contrast": 0.0, "output_recommendation": "N/A"
                })
            except Exception as e:
                logging.error(f"Failed to process {file_path.name}: {e}")
                results.append({
                    "source_image": file_path.name,
                    "output_path": "",
                    "status": f"FAILED: {e}",
                    "geometric_score": 0.0,
                    "input_sharpness": 0.0, "input_brightness": 0.0, "input_contrast": 0.0, "input_recommendation": "N/A",
                    "output_sharpness": 0.0, "output_brightness": 0.0, "output_contrast": 0.0, "output_recommendation": "N/A"
                })
                
    if processed_count == 0:
        logging.warning(f"No supported images found in {input_dir}")
        return
                
    # Save CSV
    csv_path = output_path / "scan_report.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "source_image", "output_path", "status", "geometric_score", 
            "input_sharpness", "input_brightness", "input_contrast", "input_recommendation",
            "output_sharpness", "output_brightness", "output_contrast", "output_recommendation"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    
    logging.info(f"Batch processing complete. Report saved to {csv_path}")
