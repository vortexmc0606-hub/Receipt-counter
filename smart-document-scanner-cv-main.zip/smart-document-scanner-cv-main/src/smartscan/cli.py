import argparse
import sys
from smartscan.pipeline import process_image
from smartscan.batch import process_batch
from smartscan.demo import run_demo
from smartscan.quality import analyze_quality
from smartscan.io_utils import load_image

def main():
    parser = argparse.ArgumentParser(description="SmartScan CV - Perspective-Aware Document Scanner")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Demo command
    demo_parser = subparsers.add_parser("demo", help="Run the offline demo")
    demo_parser.add_argument("--output-dir", required=True, help="Directory to save demo output")
    
    # Scan command
    scan_parser = subparsers.add_parser("scan", help="Scan a single image")
    scan_parser.add_argument("--input", required=True, help="Input image path")
    scan_parser.add_argument("--output", required=True, help="Output image path")
    scan_parser.add_argument("--mode", choices=["adaptive", "otsu", "color"], default="adaptive", help="Enhancement mode")
    scan_parser.add_argument("--boundary-output", help="Optional path to save boundary visualization")
    
    # Analyze command
    analyze_parser = subparsers.add_parser("analyze", help="Analyze image quality")
    analyze_parser.add_argument("--input", required=True, help="Input image path")
    
    # Batch command
    batch_parser = subparsers.add_parser("batch", help="Batch process a directory of images")
    batch_parser.add_argument("--input-dir", required=True, help="Input directory")
    batch_parser.add_argument("--output-dir", required=True, help="Output directory")
    batch_parser.add_argument("--mode", choices=["adaptive", "otsu", "color"], default="adaptive", help="Enhancement mode")
    
    args = parser.parse_args()
    
    try:
        if args.command == "demo":
            run_demo(args.output_dir)
        elif args.command == "scan":
            quality = process_image(args.input, args.output, args.mode, args.boundary_output)
            print(f"Scan complete. Output saved to {args.output}")
            print(f"Detection Geometric Detection Score: {quality.get('geometric_score', 0.0):.2f}")
            print("Pre-processing Quality:")
            print(f"  Sharpness: {quality['input_sharpness']:.2f}")
            print(f"  Brightness: {quality['input_brightness']:.2f}")
            print(f"  Contrast: {quality['input_contrast']:.2f}")
            print(f"  Recommendation: {quality['input_recommendation']}")
            print("Post-processing Quality:")
            print(f"  Sharpness: {quality['output_sharpness']:.2f}")
            print(f"  Brightness: {quality['output_brightness']:.2f}")
            print(f"  Contrast: {quality['output_contrast']:.2f}")
            print(f"  Recommendation: {quality['output_recommendation']}")
        elif args.command == "analyze":
            img = load_image(args.input)
            quality = analyze_quality(img)
            print(f"Quality Analysis for {args.input}:")
            for k, v in quality.items():
                print(f"  {k}: {v}")
        elif args.command == "batch":
            process_batch(args.input_dir, args.output_dir, args.mode)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
        
    return 0

if __name__ == "__main__":
    sys.exit(main())
