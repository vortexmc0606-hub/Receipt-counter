import cv2
import numpy as np
import os
from .pipeline import process_image
from .detector import detect_document
from .quality import analyze_quality

def run_demo(output_dir="output/demo"):
    """
    Generate a synthetic skewed document, run the pipeline on it, and output the results.
    """
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"Generating synthetic document at {output_dir}/synthetic_document.jpg...")
    # 1. Create a rectangular document canvas
    doc_w, doc_h = 1200, 650
    doc = np.ones((doc_h, doc_w, 3), dtype=np.uint8) * 240
    
    # Draw content on the straight document
    cv2.putText(doc, "SmartScan CV Demo", (100, 150), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 0, 0), 5, cv2.LINE_AA)
    cv2.putText(doc, "By Vanshika Rathore", (100, 300), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (50, 50, 50), 3, cv2.LINE_AA)
    cv2.putText(doc, "Computer Vision Project", (100, 400), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (50, 50, 50), 3, cv2.LINE_AA)
    cv2.rectangle(doc, (100, 450), (1100, 600), (0, 0, 0), 4)

    # 2. Create the dark background
    img = np.ones((1080, 1920, 3), dtype=np.uint8) * 50
    
    # 3. Define source and destination points
    src_pts = np.array([
        [0, 0],
        [doc_w - 1, 0],
        [doc_w - 1, doc_h - 1],
        [0, doc_h - 1]
    ], dtype="float32")
    
    dst_pts = np.array([
        [400, 200],   # Top-left
        [1600, 300],  # Top-right
        [1500, 950],  # Bottom-right
        [200, 800]    # Bottom-left
    ], dtype="float32")
    
    # 4. Warp the document
    M = cv2.getPerspectiveTransform(src_pts, dst_pts)
    warped_doc = cv2.warpPerspective(doc, M, (1920, 1080))
    
    # 5. Composite warped document onto background
    mask = cv2.warpPerspective(np.ones((doc_h, doc_w), dtype=np.uint8)*255, M, (1920, 1080))
    mask_3d = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    np.copyto(img, warped_doc, where=mask_3d == 255)
    
    # 6. Add noise/blur to make it realistic
    img = cv2.GaussianBlur(img, (5, 5), 0)
    
    # Use fixed random seed for reproducibility
    np.random.seed(42)
    noise = np.random.normal(0, 10, img.shape).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    
    input_path = os.path.join(output_dir, "synthetic_document.jpg")
    cv2.imwrite(input_path, img)
    
    print("Running SmartScan CV pipeline...\n")
    output_path = os.path.join(output_dir, "scanned_document.png")
    boundary_path = os.path.join(output_dir, "detected_boundary.png")
    
    # Process
    report = process_image(input_path, output_path, mode="adaptive")
    
    # Get boundary visualization
    corners, _ = detect_document(img)
    boundary_img = img.copy()
    cv2.polylines(boundary_img, [corners.astype(np.int32)], True, (0, 255, 0), 5)
    cv2.imwrite(boundary_path, boundary_img)
    
    print("--- Demo Results ---")
    print(f"Input: {input_path}")
    print(f"Output: {output_path}")
    print(f"Boundary Annotated: {boundary_path}")
    print(f"Geometric Detection Score: {report.get('geometric_score', 0):.2f}")
    print(f"Input Quality: Sharpness {report.get('input_sharpness', 0):.1f} | Contrast {report.get('input_contrast', 0):.1f}")
    print(f"Output Quality: Sharpness {report.get('output_sharpness', 0):.1f} | Contrast {report.get('output_contrast', 0):.1f}")
    print("--------------------")
