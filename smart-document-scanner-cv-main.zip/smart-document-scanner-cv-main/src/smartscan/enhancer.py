import cv2
import numpy as np

def enhance_image(image, mode="adaptive"):
    """
    Enhance readability of a scanned document.
    modes: 'adaptive', 'otsu', 'color'
    """
    if mode == "color":
        # Colour-preserving enhancement using CLAHE in LAB color space
        lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        limg = cv2.merge((cl, a, b))
        enhanced = cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)
        # Apply slight denoising
        enhanced = cv2.fastNlMeansDenoisingColored(enhanced, None, 10, 10, 7, 21)
        return enhanced

    # Grayscale conversion for adaptive and otsu
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Denoise
    gray = cv2.fastNlMeansDenoising(gray, None, h=10, searchWindowSize=21, templateWindowSize=7)

    if mode == "adaptive":
        # Adaptive thresholding
        enhanced = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                         cv2.THRESH_BINARY, 21, 10)
    elif mode == "otsu":
        # Otsu's thresholding
        _, enhanced = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    else:
        raise ValueError(f"Unknown mode: {mode}")

    # Return as 3 channel for consistency if original was colored? No, let's keep it 1 channel for BW,
    # or we can convert back to BGR so all outputs have the same shape.
    if len(enhanced.shape) == 2:
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)

    return enhanced
