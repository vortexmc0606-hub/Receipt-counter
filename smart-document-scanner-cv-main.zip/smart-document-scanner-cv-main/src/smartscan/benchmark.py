import time
import cv2
import numpy as np
from smartscan.pipeline import process_image

def generate_benchmark_image():
    # Use fixed random seed for reproducibility
    np.random.seed(42)
    img = np.ones((1080, 1920, 3), dtype=np.uint8) * 50
    pts = np.array([[400, 200], [1600, 300], [1500, 950], [200, 800]], np.int32)
    cv2.fillPoly(img, [pts], (240, 240, 240))
    cv2.putText(img, "Benchmark Text", (500, 500), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 0, 0), 5)
    
    noise = np.random.normal(0, 10, img.shape).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    
    cv2.imwrite("tmp_benchmark.jpg", img)

def run_benchmark(iterations=10):
    print("--- SmartScan CV Benchmark ---")
    print("Generating 1080p synthetic document...")
    generate_benchmark_image()
    
    print(f"Running pipeline {iterations} times to measure average processing time...")
    times = []
    
    for i in range(iterations):
        start = time.time()
        process_image("tmp_benchmark.jpg", "tmp_benchmark_out.png", mode="adaptive")
        end = time.time()
        times.append(end - start)
        print(f"  Run {i+1}: {times[-1]:.3f}s")
        
    avg_time = sum(times) / len(times)
    print("\n--- Benchmark Results ---")
    print("Image Size: 1920x1080")
    print(f"Samples: {iterations}")
    print(f"Average Time: {avg_time:.3f} seconds")
    print(f"Min Time: {min(times):.3f} seconds")
    print(f"Max Time: {max(times):.3f} seconds")
    
    # Clean up
    import os
    if os.path.exists("tmp_benchmark.jpg"):
        os.remove("tmp_benchmark.jpg")
    if os.path.exists("tmp_benchmark_out.png"):
        os.remove("tmp_benchmark_out.png")

if __name__ == "__main__":
    run_benchmark()
