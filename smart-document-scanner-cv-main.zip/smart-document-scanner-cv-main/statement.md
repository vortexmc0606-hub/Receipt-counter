# Problem Statement
In many professional and academic environments, users need to digitize physical documents. Photographs of documents taken with smartphones often suffer from perspective skew, poor lighting, blurriness, and low contrast. There is a need for a lightweight, automated tool that can reliably detect a document's boundaries, correct its perspective, enhance its readability, and evaluate its quality without relying on heavy cloud APIs or complex GUIs.

# Project Scope
The project delivers a pure Python, command-line utility named "SmartScan CV". It is constrained to using classical Computer Vision techniques (OpenCV) to ensure it runs entirely offline and fast. The scope includes single-image processing, batch processing, image enhancement (adaptive, Otsu, colour-preserving), and image quality diagnostics. 

# Target Users
- Students digitizing handwritten notes.
- Professionals scanning receipts or contracts.
- Server-side automation pipelines that need to clean up user-uploaded document images before OCR processing.

# High-Level Features
- **Boundary Detection:** Uses Canny Edge Detection and Contour Analysis.
- **Perspective Warp:** Maps the 4-point detected contour to a flat, top-down rectangular view.
- **Quality Diagnostics:** Reports sharpness, brightness, and contrast.
- **Enhancement:** Improves text legibility through background noise removal and binarization.
- **Batch Processing:** Bulk-processes directories and outputs a CSV report.
