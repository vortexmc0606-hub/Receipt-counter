# SmartScan CV - Perspective-Aware Document Scanner and Image Enhancer

**Student Name:** Vanshika Rathore  
**Registration Number:** 23BAI11395  
**Course:** Computer Vision - Evaluated Project  

## Overview
SmartScan CV is a complete, terminal-based Python Computer Vision project that allows users to scan paper documents from photographs. It detects document boundaries, corrects perspective (de-skewing), enhances readability using various thresholding and denoising algorithms, and analyzes image quality to provide actionable recommendations.

## Features
- **Document Boundary Detection:** Uses Canny edge detection and contour approximation to find the document corners. Includes an intelligent geometric_score score based on geometry and gracefully rejects images without documents.
- **Perspective Correction:** Flattens the document to a top-down view.
- **Image Enhancement:** Offers adaptive, Otsu, and color-preserving (CLAHE) enhancement modes.
- **Pre/Post Quality Analysis:** Evaluates sharpness, brightness, and contrast before and after processing to empirically prove image improvement.
- **Batch Processing:** Automatically processes all supported image formats in a folder and generates a detailed `scan_report.csv`.
- **Offline Demo:** Generates a synthetic skewed document and runs the pipeline locally without requiring external datasets or internet access.

## Technologies Used
- Python 3.10+
- OpenCV (headless)
- NumPy
- Pytest (for unit testing)

## Folder Structure
```text
smart_document_scanner/
├── README.md
├── statement.md
├── requirements.txt
├── pyproject.toml
├── main.py
├── src/
│   └── smartscan/
│       ├── __init__.py
│       ├── cli.py
│       ├── detector.py
│       ├── geometry.py
│       ├── enhancer.py
│       ├── quality.py
│       ├── io_utils.py
│       ├── pipeline.py
│       ├── batch.py
│       ├── benchmark.py
│       └── demo.py
├── tests/
│   ├── test_detector.py
│   ├── test_geometry.py
│   ├── test_quality.py
│   ├── test_pipeline.py
│   ├── test_batch.py
│   └── test_io.py
├── docs/
│   └── architecture.md
├── reports/
│   └── SmartScan_CV_Project_Report_Vanshika_Rathore.pdf
└── generate_report.py
```

## Setup & Installation
1. **Create and activate a virtual environment:**
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
2. **Install requirements:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Install the project locally:**
   ```bash
   pip install -e .
   ```

## Usage Commands
Once installed, you can use the `smartscan` command.

1. **Run Offline Demo:**
   ```bash
   smartscan demo --output-dir output/demo
   ```

2. **Scan a Single Image:**
   ```bash
   smartscan scan --input path/to/image.jpg --output output/scanned.png --mode adaptive --boundary-output output/boundary.png
   ```

3. **Analyze Image Quality:**
   ```bash
   smartscan analyze --input path/to/image.jpg
   ```

4. **Batch Processing:**
   ```bash
   smartscan batch --input-dir path/to/images --output-dir output/batch --mode adaptive
   ```

## Testing
Run the automated test suite using pytest:
```bash
pytest
```

## Requirements
### Functional Requirements
- Ingest common image formats (JPG, PNG, etc.).
- Robust edge detection and contour extraction.
- Perspective transformation and image warping.
- Multiple enhancement modes for varying document types.
- Batch processing with graceful failure handling for missing documents.

### Non-Functional Requirements
1. **Performance:** A local synthetic benchmark handles a standard 1080p image (1920x1080) in approximately 0.16 seconds on a standard CPU. Performance may vary on different hardware.
2. **Reliability:** The batch processor handles missing directories, corrupted files, and images with no documents without crashing.
3. **Usability:** CLI provides clear error messages and pre/post metrics.
4. **Maintainability:** Code relies on modular architecture and is comprehensively tested.
5. **Resource Efficiency:** Headless OpenCV ensures minimal RAM overhead and removes GUI dependencies, making it suitable for server or low-resource environments.

## Limitations & Future Enhancements
- **Limitations:** Struggles with documents on a background of identical color/texture. Curved documents (like thick books) are not flattened perfectly.
- **Future Enhancements:** Integrate a Deep Learning-based corner detection model (e.g., MobileNet) for complex backgrounds, and implement page de-warping for bound books.
