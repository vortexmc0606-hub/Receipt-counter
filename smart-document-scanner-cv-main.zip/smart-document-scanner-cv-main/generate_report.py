import os
from fpdf import FPDF
from pathlib import Path
import re

class PDFReport(FPDF):
    def header(self):
        self.set_font("helvetica", 'B', 14)
        self.cell(0, 10, "SmartScan CV - Project Report", border=False, new_x="LMARGIN", new_y="NEXT", align="C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("helvetica", 'I', 8)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")

def generate_report(output_path):
    pdf = PDFReport()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    
    # 1. Cover Page
    pdf.set_font("helvetica", 'B', 24)
    pdf.ln(30)
    pdf.cell(0, 15, "SmartScan CV", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("helvetica", 'I', 16)
    pdf.cell(0, 15, "Perspective-Aware Document Scanner and Image Enhancer", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(20)
    
    pdf.set_font("helvetica", '', 14)
    pdf.cell(0, 10, "Student Name: Vanshika Rathore", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 10, "Registration Number: 23BAI11395", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 10, "Course: Computer Vision - Evaluated Project", align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 10, "Date: 18 September 2026", align="C", new_x="LMARGIN", new_y="NEXT")
    
    pdf.add_page()
    
    sections = [
        ("2. Introduction", "Digitizing documents through smartphone photography often results in skewed, poorly lit, or blurry images. SmartScan CV addresses this by automatically identifying document boundaries, fixing perspective distortion, and applying image enhancement. This ensures high-quality digitization from raw photos."),
        ("3. Problem Statement", "In professional environments, digitizing physical documents with smartphone cameras often suffers from perspective skew, poor lighting, blurriness, and low contrast. There is a need for a lightweight, automated tool that can reliably detect boundaries, correct perspective, enhance readability, and evaluate image quality offline."),
        ("4. Objectives", "- Create an end-to-end perspective-aware scanning tool using classical computer vision.\n- Provide automated pre- and post-processing quality diagnosis.\n- Support various image enhancement modes.\n- Provide a CLI interface for seamless integration and batch processing."),
        ("5. Scope", "The project is limited to processing 2D image formats locally via CLI. It does not include OCR text extraction or cloud connectivity. The focus is strictly on geometric correction and image thresholding."),
        ("6. Target Users", "- Students digitizing handwritten notes.\n- Professionals scanning receipts or contracts.\n- Server-side automation pipelines cleaning up user-uploaded document images before OCR processing."),
        ("7. Functional Requirements", "- Accept common image formats (JPG, PNG, etc.).\n- Detect the 4 corners of a document automatically and calculate a Geometric Detection Score.\n- Reject images where no document is found.\n- Flatten the document to a top-down view via perspective warp.\n- Enhance image readability using adaptive, Otsu, or color-preserving methods.\n- Batch-process a directory and output a summary CSV."),
        ("8. Non-Functional Requirements", "1. Performance: A local synthetic benchmark handles images rapidly (e.g., 0.142s average for 1920x1080 over 10 runs on standard CPU). Performance may vary.\n2. Reliability: Handles exceptions gracefully during batch processing.\n3. Usability: Intuitive CLI with clear diagnostic outputs.\n4. Maintainability: Well-structured, modular, and fully tested codebase.\n5. Resource Efficiency: Utilizes headless OpenCV, suitable for GUI-less environments."),
    ]
    
    for title, content in sections:
        pdf.set_font("helvetica", 'B', 14)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("helvetica", '', 11)
        pdf.multi_cell(0, 6, content)
        pdf.ln(5)
            
    diagrams = [
        ("9. System Architecture", "docs_assets_System_Architecture.png"),
        ("10. Workflow / Process Flow", "docs_assets_Workflow___Process_Flow.png"),
        ("11. Use Case Diagram", "docs_assets_Use_Case_Diagram.png"),
        ("12. Sequence Diagram", "docs_assets_Sequence_Diagram.png"),
        ("13. Component Diagram", "docs_assets_Component___Class_Diagram.png"),
        ("14. Class Diagram", "docs_assets_Class_Diagram.png"),
    ]
    
    import cv2
    for title, img_name in diagrams:
        img_path = os.path.join("docs", "assets", img_name)
        if os.path.exists(img_path):
            pdf.add_page()
            pdf.set_font("helvetica", 'B', 14)
            pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
            
            img = cv2.imread(img_path)
            h, w = img.shape[:2]
            max_w = 170
            max_h = 240
            scale = min(max_w / w, max_h / h)
            
            pdf.image(img_path, w=w * scale, h=h * scale)
            pdf.ln(5)
            
    text_sections = [
        ("15. Design Rationale", "We chose classic CV techniques (Canny, Contours) over Deep Learning to keep the project completely offline, fast, and dependency-light. Adaptive Thresholding was chosen as the default enhancement since it robustly handles uneven lighting. Geometric Detection Scoring ensures robustness by explicitly penalizing non-quadrilaterals and rejecting small objects."),
        ("16. Computer Vision Theory", "The pipeline relies heavily on spatial gradients (Canny), topological structural analysis (findContours), and projective geometry (getPerspectiveTransform and warpPerspective)."),
        ("17. Algorithms", "1. Gaussian Blur to reduce high-frequency noise.\n2. Canny Edge Detection to identify object boundaries.\n3. Contour Area sorting to find the largest structural component.\n4. Ramer-Douglas-Peucker algorithm (approxPolyDP) for curve approximation.\n5. Projective Transformation to correct skew."),
        ("18. Implementation", "The core logic is spread across modular Python files: `detector.py` for edge/contour finding, `geometry.py` for perspective warping, `enhancer.py` for thresholding, and `quality.py` for heuristic quality metrics (Laplacian variance)."),
        ("19. Dataset / Test Images", "Testing relies on synthetically generated perspective-skewed images and standard edge cases (blank images, circles, noisy backgrounds) dynamically generated via NumPy to ensure 100% offline self-contained execution without reliance on external proprietary datasets."),
        ("20. Evaluation Methodology", "Evaluated using Pytest for unit functionality, and synthetic benchmarking for execution speed. Output quality is empirically measured by comparing input and output sharpness (variance of Laplacian) and contrast."),
        ("21. Quantitative Results", "A local synthetic benchmark on a 1920x1080 image averaged 0.142 seconds over 10 runs on this machine. Quality metrics indicate a substantial increase in Laplacian variance (sharpness), though this heuristic measure comes with a trade-off in brightness, frequently leading to an \"Overexposed\" recommendation due to aggressive binarization."),
    ]
    
    for title, content in text_sections:
        pdf.set_font("helvetica", 'B', 14)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("helvetica", '', 11)
        pdf.multi_cell(0, 6, content)
        pdf.ln(5)
        
    img1 = "output/final_demo/synthetic_document.jpg"
    img2 = "output/final_demo/detected_boundary.png"
    img3 = "output/final_demo/scanned_document.png"
    
    if os.path.exists(img1) and os.path.exists(img2) and os.path.exists(img3):
        pdf.add_page()
        pdf.set_font("helvetica", 'B', 14)
        pdf.cell(0, 10, "22. Screenshots / Results", new_x="LMARGIN", new_y="NEXT")
        
        # 1. Input Document
        pdf.set_font("helvetica", 'I', 12)
        pdf.cell(0, 10, "1. Input Document", new_x="LMARGIN", new_y="NEXT", align="C")
        pdf.image(img1, x=45, w=120)
        pdf.ln(5)
        
        # 2. Detected Boundary
        pdf.add_page()
        pdf.set_font("helvetica", 'I', 12)
        pdf.cell(0, 10, "2. Detected Boundary", new_x="LMARGIN", new_y="NEXT", align="C")
        pdf.image(img2, x=45, w=120)
        pdf.ln(5)
        
        # 3. Enhanced Output
        pdf.add_page()
        pdf.set_font("helvetica", 'I', 12)
        pdf.cell(0, 10, "3. Enhanced Output", new_x="LMARGIN", new_y="NEXT", align="C")
        pdf.image(img3, x=45, w=120)
        pdf.ln(5)
            
    final_sections = [
        ("23. Testing", "The system uses Pytest. Tests include geometric robustness (rejecting circles), successful detection, extreme fallback exceptions (blank images), empty batch handling, and full pipeline coverage. All 13 tests pass successfully."),
        ("24. Error Handling", "Robustly handles missing files (FileNotFoundError), empty batch directories (warnings), unsupported enhancement modes, and images without documents (DocumentNotFoundError)."),
        ("25. Challenges", "Handling non-rectangular documents (like circles) triggering false positives was solved by validating geometric extent against the bounding box. The trade-off between text clarity and extreme overexposure required adjusting adaptive block sizes."),
        ("26. Learnings", "Learned how to construct a resilient, fully offline CV pipeline, properly manage error states in batch processing, and empirically measure image quality using heuristics."),
        ("27. Limitations", "The tool relies heavily on contrast between the document and its background. Documents on identically colored tables may fail to detect. Highly warped pages (e.g. thick books) will not flatten perfectly using a simple homography."),
        ("28. Future Enhancements", "Integration of deep learning for robust corner detection in complex scenes. Adding page de-warping algorithms for curved book pages. Adding OCR support using Tesseract for text extraction."),
        ("29. Conclusion", "SmartScan CV successfully demonstrates an efficient, completely offline method for cleaning up physical document photographs, yielding highly readable outputs through geometric detection and adaptive enhancement."),
        ("30. References", "- OpenCV Documentation: https://docs.opencv.org/\n- \"Computer Vision: Algorithms and Applications\" by Richard Szeliski\n- PyImageSearch tutorials on Document Scanning.")
    ]
    
    for title, content in final_sections:
        pdf.set_font("helvetica", 'B', 14)
        pdf.cell(0, 10, title, new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("helvetica", '', 11)
        pdf.multi_cell(0, 6, content)
        pdf.ln(5)

    pdf.output(output_path)
    print(f"Report successfully generated at {output_path}")

if __name__ == "__main__":
    out_file = Path("reports/SmartScan_CV_Project_Report_Vanshika_Rathore.pdf")
    generate_report(str(out_file))
